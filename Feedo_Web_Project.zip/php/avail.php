<?php

// Function to perform a select query on the database
function fetchDataFromDatabase() {
    // Database credentials
    $hostname = "localhost";
    $username = "root";
    $password = "";
    $database_name = "feedo_db_1";

    // Create connection
    $conn = new mysqli($hostname, $username, $password, $database_name);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    echo "<h3>AVAILABLE FOOD DETAILS:</h3>";
    // SQL query to select data
    $sql = "SELECT food FROM admin_info ";

    // Perform the query
    $result = $conn->query($sql);

    // Check if any rows were returned
    if ($result->num_rows > 0) {
        // Output data of each row
        while($row = $result->fetch_assoc()) {
            // Access data from $row array
           
            echo  $row["food"]. "<br>";
        }
    } else {
        echo "0 results";
    }

    // Close connection
    $conn->close();
}

// Call the function to fetch and display data
fetchDataFromDatabase();

?>

