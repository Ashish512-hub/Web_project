<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "feedo_db_1";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $subject = $_POST["subject"];
    $number = $_POST["number"];
    $food=$_POST["food"];
    $Time=$_POST["Time"];

    // SQL query to insert data into the database
    $sql = "INSERT INTO admin_info (name,email,subject,number,food,Time) VALUES ('$name', '$email', '$subject', '$number','$food','$Time')";

    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close connection
$conn->close();
?>
