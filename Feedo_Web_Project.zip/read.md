you can open the home page by just navigating this link-->http://localhost/Feedo_web_page/index.html

you can open the about us page by just navigating this link-->http://localhost/Feedo_web_page/about.html

you can open the hotels page by just navigating this link-->http://localhost/Feedo_web_page/hotels.html

you can open the gallery page by just navigating this link-->http://localhost/Feedo_web_page/gallery.html

you can open the blogs page by just navigating this link-->http://localhost/Feedo_web_page/blog.html

you can open the contact us page by just navigating this link-->http://localhost/Feedo_web_page/contact.html

you can open the registration page by just navigating this link-->http://localhost/Feedo_web_page/registration.html

you can open the registration page by just navigating this link-->http://localhost/Feedo_web_page/login.html

you can open the registration page by just navigating this link-->http://localhost/Feedo_web_page/appointment.html

you can open the registration page by just navigating this link-->http://localhost/Feedo_web_page/Availability.html